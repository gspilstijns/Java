package com.crm.miniCRM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniCrmApplicationTests {

	@Test
	void contextLoads() {
	}

}
